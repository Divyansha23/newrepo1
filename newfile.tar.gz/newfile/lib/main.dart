import 'dart:io';
import 'dart:async';
import 'package:dart_appwrite/dart_appwrite.dart';

Future<dynamic> main(final context) async {
  try {
    // Initialize Appwrite client
    Client client = Client();
    client
        .setEndpoint(
            Platform.environment['APPWRITE_FUNCTION_API_ENDPOINT'] ?? '')
        .setProject(Platform.environment['APPWRITE_FUNCTION_PROJECT_ID'] ?? '')
        .setKey(Platform.environment['APPWRITE_FUNCTION_API_KEY'] ?? '');

    // Get the request method and path
    final method = context.req.method;
    final path = context.req.path;
    final queries = context.req.query;
    // final body = context.req.body;
    // final data = context.req.headers;
    // final cookieHeader = context.req.headers['cookie'];

    // return context.res.json({
    //   'queries': queries,
    //   'body': body,
    //   'cookieHeader': cookieHeader,
    //   'data': data
    // }, 200);

    if (method == 'GET') {
      if (path == '/auth/success') {
        return context.res.redirect(
            'appwrite-callback-6893730f00268e479747://login?secret=${queries['secret']}&key=${queries['userId']}');
      }

      if (path == '/auth/failure') {
        final redirectUri = 'yzedlive://oauth-failure';
        return context.res.redirect(redirectUri);
      }
    }

    return context.res.json({
      'success': false,
      'error': 'Internal server error',
      'details': 'Path not found'
    }, 500);
  } catch (e) {
    context.error('Function error: $e');
    return context.res.json({
      'success': false,
      'error': 'Internal server error',
      'details': e.toString()
    }, 500);
  }
}
